// Copyright (C) 2005  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_TIMEr_
#define DLIB_TIMEr_

#include "timer/timer.h"
#include "timer/timer_heavy.h"

#endif // DLIB_TIMEr_

