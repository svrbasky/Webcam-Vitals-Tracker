// Copyright (C) 2008  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_QUANTUM_COMPUTINg_H_
#define DLIB_QUANTUM_COMPUTINg_H_ 

#include "quantum_computing/quantum_computing.h"

#endif // DLIB_QUANTUM_COMPUTINg_H_ 




